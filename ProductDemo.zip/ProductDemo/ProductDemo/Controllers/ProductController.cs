﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using ProductDemo.Models;


namespace ProductDemo.Controllers
{
    public class ProductController : ApiController
    {
        
        CloudStorageAccount storageAccount = null;
        CloudTableClient tableClient = null;
        CloudTable table = null;
        public ProductController()
        {
            storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("Product");
            table.CreateIfNotExists();
        }
        public IEnumerable<Product> Get()
        {
            List<Product> prds = new List<Product>();
            TableQuery<ProductTableEntity> query = new TableQuery<ProductTableEntity>();
            foreach (ProductTableEntity item in table.ExecuteQuery(query))
            {
                Product prd = new Product()
                {
                    ProductID = item.RowKey,
                    ProductName = item.PartitionKey,
                    ExpirationDate = item.ExpirationDate,
                    Price = item.Price
                   
                };
                prds.Add(prd);
            }
            return prds;
        }

        


    }
}
