﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.Storage.Table;

namespace ProductDemo.Models
{
    public class Product
    {
        public string ProductID { get; set; }
        public string ProductName { get; set; }
        public string ExpirationDate { get; set; }
        public int Price { get; set; }
        
    }
    class ProductTableEntity : TableEntity
    {
        public string ExpirationDate { get; set; }
        public int Price { get; set; }

        public ProductTableEntity() { }
        public ProductTableEntity(string partitionKey, string rowKey)
        {
            this.PartitionKey = partitionKey;
            this.RowKey = rowKey;
        }

        public override string ToString()
        {
            return string.Format($"ProductName: {PartitionKey}\tProductID: {RowKey}\n\tExpirationDate: {ExpirationDate}\tPrice: {Price}");
        }
    }
}